
  This directory contains the CSS files you will be editing
  for your theme.
  
  theme.css - this is the file to use to build your theme. It contains many 
  empty CSS selectors that show up in Firebug and make prototyping styles easy.
  
  starter.css - this file includes some basic styles, you should unset this
  if you think its getting in the way of theming, its just an example.
  
  starter-rtl.css - same with above, but gives RTL support.